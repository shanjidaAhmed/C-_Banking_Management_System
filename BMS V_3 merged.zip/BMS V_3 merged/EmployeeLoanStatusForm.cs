﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Drawing.Imaging;
using System.Linq;
using System.Runtime.Remoting.Metadata.W3cXsd2001;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BankingManagementSystem
{
    public partial class EmployeeLoanStatusForm : Form
    {
        public EmployeeLoanStatusForm()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void btnDashboard_Click(object sender, EventArgs e)
        {
            EmployeeHomeForm employeeHomeForm = new EmployeeHomeForm();
            employeeHomeForm.Show();
            this.Hide();
        }

        private void btnCustomer_Click(object sender, EventArgs e)
        {
            EmployeeCustomerForm employeeCustomerForm = new EmployeeCustomerForm();
            employeeCustomerForm.Show();
            this.Hide();
        }

        private void btnLoan_Click(object sender, EventArgs e)
        {
            EmployeeLoanForm employeeLoanForm = new EmployeeLoanForm();
            employeeLoanForm.Show();
            this.Hide();
        }

        private void btnSettings_Click(object sender, EventArgs e)
        {
            EmployeeSettings1Form employeeSettings1Form = new EmployeeSettings1Form();
            employeeSettings1Form.Show();
            this.Hide();
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            DialogResult dr = MessageBox.Show("Do you want to logout?", "Logout", MessageBoxButtons.YesNo);
            if (dr == DialogResult.Yes)
            {
                LoginForm loginForm = new LoginForm();
                loginForm.Show();
                this.Hide();
            }
        }

        private void EmployeeLoanStatusForm_Load(object sender, EventArgs e)
        {
            namelbl.Text = $"Welcome, {ApplicationHelper.LoggedInName}";
            this.LoadData();
        }


        private void LoadData()
        {
            try
            {


                var con = new SqlConnection();
                con.ConnectionString = ApplicationHelper.ConnectionPath;
                con.Open();


                var cmd = new SqlCommand();
                cmd.Connection = con;
                cmd.CommandText = "select * from LoanStatus";


                DataTable dt = new DataTable();
                SqlDataAdapter adp = new SqlDataAdapter(cmd);
                adp.Fill(dt);

                con.Close();

                dGVLoanStatus.AutoGenerateColumns =false;
                dGVLoanStatus.DataSource = dt;
                dGVLoanStatus.Refresh();
                dGVLoanStatus.ClearSelection();





            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);

            }
        }

        private void newData()
        {
            txtLoanId.Text = "";
            cmbLoanStatus.Text = "";
            dGVLoanStatus.ClearSelection();


        }
        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {




                string loanStatus = cmbLoanStatus.SelectedItem.ToString();

                int selectedRowId = Convert.ToInt32(dGVLoanStatus.CurrentRow.Cells[0].Value);

                if (string.IsNullOrEmpty(loanStatus))
                {
                    MessageBox.Show("Please enter Loan ID and select a Loan Status.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }




                var con = new SqlConnection();
                con.ConnectionString = ApplicationHelper.ConnectionPath;
                con.Open();


                var cmd = new SqlCommand();
                cmd.Connection = con;
                cmd.CommandText = $"SELECT LS_Status, L_Id, A_Id FROM LoanStatus WHERE LS_Id ={selectedRowId}";

                DataTable dt = new DataTable();
                SqlDataAdapter adp = new SqlDataAdapter(cmd);
                adp.Fill(dt);


                if (dt.Rows.Count > 0)
                {
                    string currentStatus = dt.Rows[0]["LS_Status"].ToString().Trim();

                    if (currentStatus == "Approved" || currentStatus == "Rejected")
                    {
                        MessageBox.Show($"This loan has already been {currentStatus}. You cannot change it again.",
                            "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }


                    int loanId = Convert.ToInt32(dt.Rows[0]["L_Id"]);
                    int accountId = Convert.ToInt32(dt.Rows[0]["A_Id"]);

                    

                    if (loanStatus == "Approved")
                    {
                        var cmdLoan = new SqlCommand();
                        cmdLoan.Connection = con;
                        cmdLoan.CommandText = $"SELECT L_MaximumAmount FROM Loan WHERE L_Id = {loanId}";
                        DataTable dtLoan = new DataTable();
                        SqlDataAdapter adpLoan = new SqlDataAdapter(cmdLoan);
                        adpLoan.Fill(dtLoan);

                        if (dtLoan.Rows.Count > 0)
                        {
                            int MaximumAmount = Convert.ToInt32(dtLoan.Rows[0]["L_MaximumAmount"]);
                            var cmd1 = new SqlCommand();
                            cmd1.Connection = con;
                            cmd1.CommandText = $"update LoanStatus set LS_Status ='{loanStatus}', LS_DisbursementDate = CONVERT(DATE, GETDATE()) WHERE LS_Id ={selectedRowId};" +
                                $"UPDATE Account SET A_Balance = A_Balance + {MaximumAmount} WHERE A_Id = {accountId}";
                            cmd1.ExecuteNonQuery();
                        }
                    }
                    else
                    {
                        var cmd1 = new SqlCommand();
                        cmd1.Connection = con;
                        cmd1.CommandText = $"update LoanStatus SET  LS_Status ='{loanStatus}'where LS_Id = {selectedRowId}";
                        cmd1.ExecuteNonQuery();

                    }


                        //cmd1.ExecuteNonQuery();



                        dGVLoanStatus.Refresh();

                        this.LoadData();
                        this.newData();
                        con.Close();
                    }
                }
            


            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }



        private void dGVLoanStatus_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            txtLoanId.Text = dGVLoanStatus.Rows[e.RowIndex].Cells[0].Value.ToString();
            cmbLoanStatus.Text = dGVLoanStatus.Rows[e.RowIndex].Cells[3].Value.ToString();


        }
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void txtLoanId_TextChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click_1(object sender, EventArgs e)
        {

        }

        private void namelbl_Click(object sender, EventArgs e)
        {

        }

        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void tableLayoutPanel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void lblLoginTime_Click(object sender, EventArgs e)
        {

        }

        private void EmployeeLoanStatusForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        
    }
}
